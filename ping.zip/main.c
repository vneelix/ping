#include "ping.h"

#include <stdio.h>

struct addrinfo	*dns_lookup(const char *address, int ai_family) {
	struct addrinfo hints;
	ft_memset(&hints, 0, sizeof(hints));
	hints.ai_family = ai_family;
	struct addrinfo *node = NULL;
	if (getaddrinfo(address, NULL, &hints, &node) != 0)
		return (NULL);
	struct addrinfo *ai = malloc(sizeof(struct addrinfo));
	if (ai == NULL) {
		freeaddrinfo(node);
		return (NULL);
	}
	ft_memcpy((void *)ai, (const void*)node, sizeof(struct addrinfo));
	ai->ai_next = NULL;
	freeaddrinfo(node);
	return (ai);
}

int		socket_create(int domain, uint8_t ttl_override, uint8_t ttl) {
	int	sock = socket(domain, SOCK_RAW, (domain == AF_INET ? IPPROTO_ICMP : IPPROTO_ICMPV6));
	if (sock == -1)
		return (-1);
	if (ttl_override == 1) {
		int ret = setsockopt(sock, (domain == AF_INET ? IPPROTO_IP : IPPROTO_IPV6), IP_TTL, &ttl, sizeof(ttl));
		if (ret != 0)
			fprintf(stderr, "ft_ping: warning: failed to set socket parameter: ttl %hhu\n", ttl);
	}
	return (sock);
}

struct msghdr	*create_msghdr(size_t buffer_len, size_t msg_controllen) {
	size_t total_len = sizeof(struct msghdr) + sizeof(struct iovec) + buffer_len + msg_controllen;
	struct msghdr *msghdr = (struct msghdr*)malloc(total_len);
	if (msghdr == NULL)
		return (NULL);
	ft_memset((void*)msghdr, 0, total_len);

	msghdr->msg_iovlen = 1;
	msghdr->msg_iov = (void*)msghdr + sizeof(struct msghdr);
	msghdr->msg_iov->iov_len = buffer_len;
	msghdr->msg_iov->iov_base = (void*)msghdr + sizeof(struct msghdr) + sizeof(struct iovec);

	if (msg_controllen != 0) {
		msghdr->msg_controllen = msg_controllen;
		msghdr->msg_control = (void*)msghdr + sizeof(struct msghdr) + sizeof(struct iovec) + buffer_len;
	}

	return (msghdr);
}

uint16_t	ft_swap_endian16(uint16_t value) {
	return (
		((value & (uint16_t)0xff00) >> 8)
			| ((value & (uint16_t)0x00ff) << 8)
	);
}

int	icmp_reply_handler(struct msghdr *msghdr, ssize_t recieved_bytes) {
	icmp_packet4 *packet = (icmp_packet4*)msghdr->msg_iov->iov_base;
	if (packet->iphdr.ip_p != IPPROTO_ICMP)
		return (UNEXPECTED_PACKET);

	switch (packet->icmphdr.type) {
		case ICMP_ECHOREPLY:
			if (packet->icmphdr.un.echo.id != getpid())
				return (UNEXPECTED_PACKET);
			return (0);
			break;
		case ICMP_TIME_EXCEEDED:
			packet = (void*)packet + sizeof(icmp_packet4);
			if (packet->icmphdr.un.echo.id != getpid())
				return (UNEXPECTED_PACKET);
			return (TTL_EXPIRED_IN_TRANSIT);
			break;
		default:
			break;
	}
	return (0);
}

int	init_ping(t_config *config, int *sock, void **icmphdr, struct msghdr **msghdr) {
	int s = socket_create(config->domain, config->ttl_override, config->ttl);
	if (s == -1) {
		fprintf(stderr, "ft_ping: error: failed to create socket\n");
		return (-1);
	}
	void *hdr = create_icmphdr_with_payload(ICMP_ECHO, (uint16_t)getpid(), config->payload_size);
	if (hdr == NULL) {
		fprintf(stderr, "ft_ping: error: failed to create ICMP header: size %hu\n", config->payload_size);
		close(s);
		return (-1);
	}
	struct msghdr *message_hdr = create_msghdr(512, 0);
	if (msghdr == NULL) {
		fprintf(stderr, "ft_ping: error: failed to prepare the environment: struct msghdr alloc\n");
		free(hdr);
		close(s);
		return (-1);
	}
	*sock = s;
	*icmphdr = hdr;
	*msghdr = message_hdr;
	return (0);
}

int	ping(t_config *config) {
	int sock;
	void *icmphdr;
	struct msghdr *msghdr;
	if (init_ping(config, &sock, &icmphdr, &msghdr) == -1)
		return (-1);

	// get char representation of address
	char ip_src[INET6_ADDRSTRLEN];
	ft_memset((void*)ip_src, 0, sizeof(ip_src));
	{
		void *addr = NULL;
		if (config->domain == AF_INET)
			addr = &((struct sockaddr_in*)config->ai->ai_addr)->sin_addr;
		else
			addr = &((struct sockaddr_in6*)config->ai->ai_addr)->sin6_addr;
		const char *ret = inet_ntop(config->domain, addr, ip_src, (socklen_t)sizeof(ip_src));
	}

	fprintf(stdout, "ft_ping (%s) %hu(%hu) bytes of data.\n",
			ip_src, config->payload_size, (uint16_t)(config->payload_size + 28));

	size_t msglen = sizeof(struct icmphdr) + config->payload_size;
	const struct sockaddr *addr = config->ai->ai_addr;
	socklen_t addrlen = config->ai->ai_addrlen;

	for (uint64_t attempt = 0; attempt != config->attempts_count; attempt++) {
		ssize_t	ret = sendto(sock, icmphdr, msglen, 0, addr, addrlen);
		if (ret == -1) {
				fprintf(stdout, "ft_ping: error: unable to send packet\n");
				break;
		}
		ret = recvmsg(sock, msghdr, MSG_DONTWAIT);
		if (ret != -1)
			ret = icmp_reply_handler(msghdr, ret);
		sleep(1);
	}
}

int	main(int argc, char *argv[]) {
	t_config config;
	ft_memset(&config, 0, sizeof(config));
	// set default values
	config.payload_size = 56;
	config.attempts_count = ~(uint64_t)0;
	if (argv_handler(argc, argv, &config) == -1)
		exit(EXIT_FAILURE);
	ping(&config);
		exit(EXIT_FAILURE);
	exit(EXIT_SUCCESS);

	// uint8_t	io[256] = {};
	// struct iovec	iov[1] = {
	// 	{io, sizeof(io)}
	// };

	// struct msghdr msg = {};
	// msg.msg_iovlen = 1;
	// msg.msg_iov = iov;

	// ret = recvmsg(r_sock, &msg, MSG_WAITALL);

	return (0);
}
