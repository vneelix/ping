#ifndef	PING_H
#define	PING_H

#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/ip_icmp.h>

#include <stdio.h>
#include <string.h>
#include <strings.h>

#include "minilib/minilib.h"

typedef enum	e_icmp_request {
	UNEXPECTED_PACKET = -2,
	TTL_EXPIRED_IN_TRANSIT,
	REQUEST_SUCCESS
}				t_icmp_request;

typedef struct	icmp_packet4 {
	struct ip		iphdr;
	struct icmphdr	icmphdr;
}				icmp_packet4;

typedef struct	s_config {
	// main parameters
	struct	addrinfo	*ai;
	int					domain;
	uint16_t			payload_size;

	// additional parameters
	uint8_t				ttl;
	uint8_t				ttl_override;
	uint64_t			attempts_count;
}				t_config;

struct addrinfo	*dns_lookup(const char *address, int ai_family);

uint16_t	checksum_rfc1071(void *data, int length);
void		*create_icmphdr_with_payload(uint8_t type, uint16_t id, uint16_t plen);

int			argv_handler(int argc, char *argv[], t_config *config);

#endif
