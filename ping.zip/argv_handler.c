/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argv_handler.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vneelix <vneelix@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/15 00:19:44 by vneelix           #+#    #+#             */
/*   Updated: 2022/03/20 17:38:03 by vneelix          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ping.h"

int	argv_handler(int argc, char *argv[], t_config *config) {
	const char	*address = NULL;
	for (int i = 1; i != argc; i++) {
		if (strcmp(argv[i], "-h") == 0)
			// print_info();
			;
		else if (strcmp(argv[i], "-v") == 0)
			;
		else if (strcmp(argv[i], "-4") == 0 || strcmp(argv[i], "-6") == 0)
			config->domain = *(uint16_t*)(argv[i]) == *(uint16_t*)("-4") ? AF_INET : AF_INET6;
		else if (strcmp(argv[i], "-s") == 0)
		{
			if (i + 1 == argc || is_number(argv[i + 1]) != 1) {
				fprintf(stderr, "ft_ping: -s invalid argument: %s\n", i + 1 == argc ? "(null)" : argv[i + 1]);
				return (-1);
			}
			config->payload_size = ft_atoi(argv[i + 1]);
		}
		else if (strcmp(argv[i], "-t") == 0)
		{
			if (i + 1 == argc || is_number(argv[i + 1]) != 1) {
				fprintf(stderr, "ft_ping: -t invalid argument: %s\n", i + 1 == argc ? "(null)" : argv[i + 1]);
				return (-1);
			}
			config->ttl_override = 1;
			config->ttl = ft_atoi(argv[i + 1]); 
		}
		else if (argv[i][0] != '-')
			address = argv[i];
		else
		{
			fprintf(stderr, "ft_ping: invalid option: %s\n", argv[i]);
			return (-1);
		}
	}
	if (address == NULL) {
		fprintf(stderr, "ft_ping: usage error: destination address required\n");
		return (-1);
	}
	config->ai = dns_lookup(address, config->domain);
	if (config->ai == NULL) {
		fprintf(stderr, "ft_ping: %s: Name or service not known\n", address);
		return (-1);
	}
	return (0);
}
