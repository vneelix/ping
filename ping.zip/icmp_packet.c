/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   icmp_packet.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vneelix <vneelix@student.21-school.ru>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/09 23:46:20 by vneelix           #+#    #+#             */
/*   Updated: 2022/03/20 17:58:50 by vneelix          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ping.h"

void	*create_icmphdr_with_payload(uint8_t type, uint16_t id, uint16_t payload_size) {
	void	*memory = malloc(sizeof(struct icmphdr) + payload_size);
	if (memory == NULL)
		return (NULL);
	ft_memset(memory, 0, sizeof(struct icmphdr) + payload_size);
	struct icmphdr *icmphdr = (struct icmphdr*)memory;
	icmphdr->type = type;
	icmphdr->un.echo.id = id;
	icmphdr->un.echo.sequence = 1;
	icmphdr->checksum = checksum_rfc1071(memory, sizeof(struct icmphdr) + payload_size);
	return (memory);
}
